# Insta Picloader web extension

Adds download buttons to posts/stories.

Supports dark theme.
